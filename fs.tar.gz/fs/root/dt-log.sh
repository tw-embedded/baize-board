#!/bin/sh

echo "i need write files"
touch /tmp/dt-log.txt
echo "end"
